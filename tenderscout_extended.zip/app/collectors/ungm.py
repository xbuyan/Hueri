import logging
import time
from typing import List, Dict, Any
import requests
from bs4 import BeautifulSoup
from app.config import settings

logger = logging.getLogger("collectors.ungm")

class UNGMCollectorError(Exception):
    pass

class UNGMCollector:
    SEARCH_URL = "https://www.ungm.org/Public/Notice/Search"

    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124.0.0.0 Safari/537.36"
        }

    def fetch_recent_notices(self) -> List[Dict[str, Any]]:
        last_exc = None
        for attempt in range(1, settings.COLLECTOR_MAX_RETRIES + 1):
            try:
                res = requests.get(self.SEARCH_URL, headers=self.headers, timeout=15)
                res.raise_for_status()
                return self._parse_html(res.text)
            except Exception as exc:
                last_exc = exc
                logger.warning("UNGM attempt %d failed: %s", attempt, exc)
                time.sleep(2 ** (attempt - 1))
        raise UNGMCollectorError(f"UNGM collection failed: {last_exc}")

    def _parse_html(self, html: str) -> List[Dict[str, Any]]:
        soup = BeautifulSoup(html, "html.parser")
        notices = []
        rows = soup.select("table.table tbody tr")
        for idx, row in enumerate(rows[:10]):
            cols = row.find_all("td")
            if len(cols) >= 3:
                title = cols[0].text.strip()
                buyer = cols[1].text.strip() if len(cols) > 1 else "UN Agency"
                notices.append({
                    "external_id": f"UNGM-{idx + 1000}",
                    "source": "UNGM",
                    "title": title,
                    "buyer": buyer,
                    "url": "https://www.ungm.org/Public/Notice",
                    "deadline_str": "Open",
                    "raw_summary": f"UNGM notice from {buyer}: {title}"
                })
        return notices

ungm_collector = UNGMCollector()
