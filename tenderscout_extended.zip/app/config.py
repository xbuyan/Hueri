import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "TenderScout AI"
    SECRET_KEY: str = os.getenv("SECRET_KEY", "super-secret-production-key-change-in-env")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7

    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", 
        "postgresql+asyncpg://postgres:postgres@localhost:5432/tenderscout"
    )
    
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    AFRICASTALKING_USERNAME: str = os.getenv("AFRICASTALKING_USERNAME", "sandbox")
    AFRICASTALKING_API_KEY: str = os.getenv("AFRICASTALKING_API_KEY", "")

    COLLECTOR_MAX_RETRIES: int = int(os.getenv("COLLECTOR_MAX_RETRIES", "3"))
    ALLOW_MOCK_FALLBACK: bool = os.getenv("ALLOW_MOCK_FALLBACK", "false").lower() == "true"

    class Config:
        env_file = ".env"

settings = Settings()
